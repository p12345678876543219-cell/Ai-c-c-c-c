# Gemini Browser Assistant (Objective-C)

Ứng dụng iOS độc lập dạng mini-browser + trợ lý Gemini. Dự án không tiêm dylib vào Cốc Cốc và không thể hiển thị overlay trên ứng dụng khác.

## Tính năng
- Mini-browser dùng WKWebView.
- Chạm 3 lần trong ứng dụng để mở/đóng bảng điều khiển.
- Nút AI nổi có thể kéo thả và bật/tắt.
- Chụp nội dung trang đang hiển thị trong WKWebView của chính ứng dụng.
- Gửi ảnh đến Gemini `generateContent`, nhận câu trả lời tiếng Việt.
- Lưu API key trong iOS Keychain.

## Giới hạn iOS
iOS sandbox không cho app tự chụp hoặc vẽ giao diện phủ lên ứng dụng Cốc Cốc. Nếu muốn phân tích trang đang mở trong Cốc Cốc, hãy dùng chức năng chụp màn hình của iPhone, sau đó có thể bổ sung tính năng chọn ảnh từ thư viện vào ứng dụng. Bản mẫu này phân tích trang được mở bên trong mini-browser của nó.

## Build bằng GitHub Actions
1. Tạo repository GitHub mới.
2. Tải toàn bộ nội dung ZIP này lên repository, giữ nguyên cấu trúc thư mục.
3. Mở tab **Actions**.
4. Chọn workflow **Build Gemini Browser Assistant** và bấm **Run workflow**.
5. Khi chạy thành công, mở run vừa hoàn tất, tải artifact `GeminiBrowserAssistant-unsigned-ipa`.

IPA tạo ra là **unsigned** (chưa ký). Nó không thể cài trực tiếp bằng ESign cho đến khi được ký bằng chứng chỉ/provisioning profile hợp lệ. GitHub Actions ở đây chỉ biên dịch và đóng gói.

## Dùng ứng dụng
1. Cài bản IPA đã được ký hợp lệ.
2. Mở ứng dụng, nhập địa chỉ web vào thanh trên cùng.
3. Chạm 3 lần vào màn hình để mở menu.
4. Dán Gemini API Key và bấm **Lưu API Key**.
5. Bấm **Chụp trang & phân tích** hoặc nút AI nổi.
6. Đọc kết quả trong bảng trợ lý.

## API
Ứng dụng gọi Gemini REST `models.generateContent` với ảnh `inline_data` và header `x-goog-api-key`. Model mặc định trong `ViewController.m` là `gemini-3.8-flash`; nếu model không khả dụng với API key/tài khoản của bạn, thay tên model bằng model vision đang được Google AI Studio hiển thị cho tài khoản.

Tài liệu: https://ai.google.dev/gemini-api/docs/generate-content/image-understanding

## Bảo mật
- Không commit API key vào GitHub.
- API key được lưu cục bộ trong Keychain của thiết bị.
- Ảnh trang web sẽ được gửi đến dịch vụ Gemini để phân tích; không gửi trang chứa thông tin riêng tư/nhạy cảm.
- Đây là mã nguồn mẫu; cần thử nghiệm và ký ứng dụng trước khi sử dụng thực tế.

## Yêu cầu
- Xcode 16 trở lên / GitHub Actions macOS runner.
- iOS 15 trở lên.
