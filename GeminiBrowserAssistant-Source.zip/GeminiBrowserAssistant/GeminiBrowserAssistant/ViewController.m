#import "ViewController.h"
#import <WebKit/WebKit.h>
#import <Security/Security.h>

@interface ViewController () <UITextFieldDelegate, WKNavigationDelegate>
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) UITextField *addressField;
@property (nonatomic, strong) UIButton *assistantButton;
@property (nonatomic, strong) UIView *menuView;
@property (nonatomic, strong) UITextField *apiKeyField;
@property (nonatomic, strong) UISwitch *assistantSwitch;
@property (nonatomic, strong) UITextView *answerView;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic) BOOL menuVisible;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.055 green:0.065 blue:0.10 alpha:1.0];
    [self buildBrowser];
    [self buildAssistantButton];
    [self buildMenu];
    UITapGestureRecognizer *tripleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toggleMenu)];
    tripleTap.numberOfTapsRequired = 3;
    tripleTap.numberOfTouchesRequired = 1;
    [self.view addGestureRecognizer:tripleTap];
    [self loadURLString:@"https://www.google.com"];
}

- (UIColor *)panelColor {
    return [UIColor colorWithRed:0.12 green:0.14 blue:0.21 alpha:0.96];
}
- (UIColor *)accentColor {
    return [UIColor colorWithRed:0.48 green:0.36 blue:1.0 alpha:1.0];
}
- (UILabel *)label:(NSString *)text size:(CGFloat)size weight:(UIFontWeight)weight {
    UILabel *label = [UILabel new];
    label.text = text;
    label.textColor = UIColor.whiteColor;
    label.font = [UIFont systemFontOfSize:size weight:weight];
    return label;
}
- (UIButton *)button:(NSString *)title action:(SEL)action {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    b.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    b.backgroundColor = self.accentColor;
    b.layer.cornerRadius = 12;
    [b addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return b;
}

- (void)buildBrowser {
    UIView *top = [[UIView alloc] initWithFrame:CGRectZero];
    top.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:top];

    self.addressField = [[UITextField alloc] initWithFrame:CGRectZero];
    self.addressField.translatesAutoresizingMaskIntoConstraints = NO;
    self.addressField.backgroundColor = [UIColor colorWithWhite:1 alpha:0.10];
    self.addressField.textColor = UIColor.whiteColor;
    self.addressField.tintColor = UIColor.whiteColor;
    self.addressField.layer.cornerRadius = 10;
    self.addressField.font = [UIFont systemFontOfSize:14];
    self.addressField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.addressField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.addressField.keyboardType = UIKeyboardTypeURL;
    self.addressField.returnKeyType = UIReturnKeyGo;
    self.addressField.delegate = self;
    self.addressField.placeholder = @"Nhập địa chỉ website";
    self.addressField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Nhập địa chỉ website" attributes:@{NSForegroundColorAttributeName:[UIColor colorWithWhite:1 alpha:0.55]}];
    UIView *pad = [[UIView alloc] initWithFrame:CGRectMake(0,0,10,1)];
    self.addressField.leftView = pad;
    self.addressField.leftViewMode = UITextFieldViewModeAlways;
    [top addSubview:self.addressField];

    UIButton *go = [self button:@"Đi" action:@selector(goPressed)];
    go.translatesAutoresizingMaskIntoConstraints = NO;
    [top addSubview:go];

    WKWebViewConfiguration *config = [WKWebViewConfiguration new];
    self.webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:config];
    self.webView.translatesAutoresizingMaskIntoConstraints = NO;
    self.webView.navigationDelegate = self;
    self.webView.backgroundColor = UIColor.whiteColor;
    [self.view addSubview:self.webView];

    UILayoutGuide *safe = self.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
        [top.topAnchor constraintEqualToAnchor:safe.topAnchor constant:8],
        [top.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:12],
        [top.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-12],
        [top.heightAnchor constraintEqualToConstant:46],
        [self.addressField.leadingAnchor constraintEqualToAnchor:top.leadingAnchor],
        [self.addressField.topAnchor constraintEqualToAnchor:top.topAnchor],
        [self.addressField.bottomAnchor constraintEqualToAnchor:top.bottomAnchor],
        [self.addressField.trailingAnchor constraintEqualToAnchor:go.leadingAnchor constant:-8],
        [go.trailingAnchor constraintEqualToAnchor:top.trailingAnchor],
        [go.topAnchor constraintEqualToAnchor:top.topAnchor],
        [go.bottomAnchor constraintEqualToAnchor:top.bottomAnchor],
        [go.widthAnchor constraintEqualToConstant:54],
        [self.webView.topAnchor constraintEqualToAnchor:top.bottomAnchor constant:10],
        [self.webView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.webView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.webView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor]
    ]];
}

- (void)buildAssistantButton {
    self.assistantButton = [self button:@"AI" action:@selector(analyzePage)];
    self.assistantButton.translatesAutoresizingMaskIntoConstraints = NO;
    self.assistantButton.layer.cornerRadius = 28;
    self.assistantButton.layer.borderWidth = 2;
    self.assistantButton.layer.borderColor = [UIColor colorWithRed:0.25 green:0.9 blue:0.95 alpha:1].CGColor;
    self.assistantButton.backgroundColor = [UIColor colorWithRed:0.23 green:0.16 blue:0.52 alpha:0.96];
    [self.view addSubview:self.assistantButton];
    [NSLayoutConstraint activateConstraints:@[
        [self.assistantButton.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-18],
        [self.assistantButton.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-24],
        [self.assistantButton.widthAnchor constraintEqualToConstant:56],
        [self.assistantButton.heightAnchor constraintEqualToConstant:56]
    ]];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragAssistant:)];
    [self.assistantButton addGestureRecognizer:pan];
}

- (void)dragAssistant:(UIPanGestureRecognizer *)pan {
    CGPoint delta = [pan translationInView:self.view];
    CGPoint center = self.assistantButton.center;
    center.x += delta.x; center.y += delta.y;
    CGFloat half = 28;
    center.x = MAX(half + 8, MIN(self.view.bounds.size.width - half - 8, center.x));
    center.y = MAX(self.view.safeAreaInsets.top + half, MIN(self.view.bounds.size.height - self.view.safeAreaInsets.bottom - half, center.y));
    self.assistantButton.center = center;
    [pan setTranslation:CGPointZero inView:self.view];
}

- (void)buildMenu {
    self.menuView = [[UIView alloc] initWithFrame:CGRectZero];
    self.menuView.translatesAutoresizingMaskIntoConstraints = NO;
    self.menuView.backgroundColor = self.panelColor;
    self.menuView.layer.cornerRadius = 22;
    self.menuView.layer.borderWidth = 1;
    self.menuView.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.18].CGColor;
    self.menuView.layer.shadowColor = UIColor.blackColor.CGColor;
    self.menuView.layer.shadowOpacity = 0.35;
    self.menuView.layer.shadowRadius = 20;
    self.menuView.hidden = YES;
    [self.view addSubview:self.menuView];

    UILabel *title = [self label:@"GEMINI BROWSER ASSISTANT" size:16 weight:UIFontWeightBold];
    title.translatesAutoresizingMaskIntoConstraints = NO;
    [self.menuView addSubview:title];

    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.translatesAutoresizingMaskIntoConstraints = NO;
    [close setTitle:@"✕" forState:UIControlStateNormal];
    [close setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont boldSystemFontOfSize:20];
    [close addTarget:self action:@selector(toggleMenu) forControlEvents:UIControlEventTouchUpInside];
    [self.menuView addSubview:close];

    UILabel *keyLabel = [self label:@"Gemini API Key" size:13 weight:UIFontWeightSemibold];
    keyLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.menuView addSubview:keyLabel];

    self.apiKeyField = [UITextField new];
    self.apiKeyField.translatesAutoresizingMaskIntoConstraints = NO;
    self.apiKeyField.placeholder = @"Dán API key tại đây";
    self.apiKeyField.secureTextEntry = YES;
    self.apiKeyField.textColor = UIColor.whiteColor;
    self.apiKeyField.backgroundColor = [UIColor colorWithWhite:1 alpha:0.09];
    self.apiKeyField.layer.cornerRadius = 10;
    self.apiKeyField.font = [UIFont systemFontOfSize:13];
    self.apiKeyField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.apiKeyField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    UIView *keyPad = [[UIView alloc] initWithFrame:CGRectMake(0,0,10,1)];
    self.apiKeyField.leftView = keyPad;
    self.apiKeyField.leftViewMode = UITextFieldViewModeAlways;
    [self.menuView addSubview:self.apiKeyField];

    UILabel *toggleLabel = [self label:@"Hiện nút AI nổi" size:14 weight:UIFontWeightMedium];
    toggleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.menuView addSubview:toggleLabel];

    self.assistantSwitch = [UISwitch new];
    self.assistantSwitch.translatesAutoresizingMaskIntoConstraints = NO;
    self.assistantSwitch.on = YES;
    [self.assistantSwitch addTarget:self action:@selector(toggleAssistant:) forControlEvents:UIControlEventValueChanged];
    [self.menuView addSubview:self.assistantSwitch];

    UIButton *save = [self button:@"Lưu API Key" action:@selector(saveAPIKey)];
    save.translatesAutoresizingMaskIntoConstraints = NO;
    [self.menuView addSubview:save];

    UIButton *analyze = [self button:@"Chụp trang & phân tích" action:@selector(analyzePage)];
    analyze.translatesAutoresizingMaskIntoConstraints = NO;
    [self.menuView addSubview:analyze];

    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    self.spinner.translatesAutoresizingMaskIntoConstraints = NO;
    self.spinner.color = UIColor.whiteColor;
    [self.menuView addSubview:self.spinner];

    self.answerView = [UITextView new];
    self.answerView.translatesAutoresizingMaskIntoConstraints = NO;
    self.answerView.backgroundColor = [UIColor colorWithWhite:1 alpha:0.07];
    self.answerView.textColor = UIColor.whiteColor;
    self.answerView.font = [UIFont systemFontOfSize:13];
    self.answerView.layer.cornerRadius = 10;
    self.answerView.editable = NO;
    self.answerView.text = @"Kết quả phân tích sẽ xuất hiện ở đây.";
    [self.menuView addSubview:self.answerView];

    [NSLayoutConstraint activateConstraints:@[
        [self.menuView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.menuView.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
        [self.menuView.widthAnchor constraintEqualToConstant:MIN(UIScreen.mainScreen.bounds.size.width - 28, 360)],
        [self.menuView.heightAnchor constraintEqualToConstant:440],
        [title.topAnchor constraintEqualToAnchor:self.menuView.topAnchor constant:18],
        [title.leadingAnchor constraintEqualToAnchor:self.menuView.leadingAnchor constant:16],
        [close.trailingAnchor constraintEqualToAnchor:self.menuView.trailingAnchor constant:-12],
        [close.centerYAnchor constraintEqualToAnchor:title.centerYAnchor],
        [close.widthAnchor constraintEqualToConstant:34],
        [keyLabel.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:18],
        [keyLabel.leadingAnchor constraintEqualToAnchor:title.leadingAnchor],
        [self.apiKeyField.topAnchor constraintEqualToAnchor:keyLabel.bottomAnchor constant:7],
        [self.apiKeyField.leadingAnchor constraintEqualToAnchor:self.menuView.leadingAnchor constant:16],
        [self.apiKeyField.trailingAnchor constraintEqualToAnchor:self.menuView.trailingAnchor constant:-16],
        [self.apiKeyField.heightAnchor constraintEqualToConstant:40],
        [toggleLabel.topAnchor constraintEqualToAnchor:self.apiKeyField.bottomAnchor constant:14],
        [toggleLabel.leadingAnchor constraintEqualToAnchor:title.leadingAnchor],
        [self.assistantSwitch.centerYAnchor constraintEqualToAnchor:toggleLabel.centerYAnchor],
        [self.assistantSwitch.trailingAnchor constraintEqualToAnchor:self.menuView.trailingAnchor constant:-18],
        [save.topAnchor constraintEqualToAnchor:toggleLabel.bottomAnchor constant:14],
        [save.leadingAnchor constraintEqualToAnchor:self.menuView.leadingAnchor constant:16],
        [save.widthAnchor constraintEqualToAnchor:self.menuView.widthAnchor multiplier:0.42 constant:-10],
        [save.heightAnchor constraintEqualToConstant:42],
        [analyze.topAnchor constraintEqualToAnchor:save.topAnchor],
        [analyze.trailingAnchor constraintEqualToAnchor:self.menuView.trailingAnchor constant:-16],
        [analyze.leadingAnchor constraintEqualToAnchor:save.trailingAnchor constant:10],
        [analyze.heightAnchor constraintEqualToConstant:42],
        [self.spinner.topAnchor constraintEqualToAnchor:save.bottomAnchor constant:8],
        [self.spinner.centerXAnchor constraintEqualToAnchor:self.menuView.centerXAnchor],
        [self.answerView.topAnchor constraintEqualToAnchor:self.spinner.bottomAnchor constant:6],
        [self.answerView.leadingAnchor constraintEqualToAnchor:self.menuView.leadingAnchor constant:16],
        [self.answerView.trailingAnchor constraintEqualToAnchor:self.menuView.trailingAnchor constant:-16],
        [self.answerView.bottomAnchor constraintEqualToAnchor:self.menuView.bottomAnchor constant:-16]
    ]];
    NSString *saved = [self readAPIKey];
    if (saved.length) self.apiKeyField.text = saved;
}

- (void)toggleMenu {
    self.menuVisible = !self.menuVisible;
    self.menuView.hidden = !self.menuVisible;
    if (self.menuVisible) [self.view bringSubviewToFront:self.menuView];
}
- (void)toggleAssistant:(UISwitch *)sender {
    self.assistantButton.hidden = !sender.isOn;
}
- (void)goPressed {
    [self.addressField resignFirstResponder];
    [self loadURLString:self.addressField.text ?: @""];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self goPressed];
    return YES;
}
- (void)loadURLString:(NSString *)raw {
    NSString *s = [raw stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (!s.length) return;
    if (![s containsString:@"://"]) s = [@"https://" stringByAppendingString:s];
    NSURL *url = [NSURL URLWithString:s];
    if (!url || !url.host.length) {
        self.answerView.text = @"Địa chỉ website không hợp lệ.";
        return;
    }
    self.addressField.text = s;
    [self.webView loadRequest:[NSURLRequest requestWithURL:url]];
}
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    self.addressField.text = webView.URL.absoluteString ?: @"";
}

#pragma mark - Keychain
- (void)saveAPIKey {
    NSString *key = [self.apiKeyField.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (!key.length) {
        self.answerView.text = @"Bạn chưa nhập API Key.";
        return;
    }
    NSData *data = [key dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *query = @{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword,
                            (__bridge id)kSecAttrService:@"GeminiBrowserAssistant",
                            (__bridge id)kSecAttrAccount:@"GeminiAPIKey"};
    SecItemDelete((__bridge CFDictionaryRef)query);
    NSMutableDictionary *item = [query mutableCopy];
    item[(__bridge id)kSecValueData] = data;
    OSStatus status = SecItemAdd((__bridge CFDictionaryRef)item, NULL);
    self.answerView.text = (status == errSecSuccess) ? @"Đã lưu API Key trong Keychain của thiết bị." : @"Không lưu được API Key. Hãy thử lại.";
}
- (NSString *)readAPIKey {
    NSDictionary *query = @{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword,
                            (__bridge id)kSecAttrService:@"GeminiBrowserAssistant",
                            (__bridge id)kSecAttrAccount:@"GeminiAPIKey",
                            (__bridge id)kSecReturnData:@YES,
                            (__bridge id)kSecMatchLimit:(__bridge id)kSecMatchLimitOne};
    CFTypeRef result = NULL;
    if (SecItemCopyMatching((__bridge CFDictionaryRef)query, &result) != errSecSuccess) return nil;
    NSData *data = CFBridgingRelease(result);
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

#pragma mark - Screenshot + Gemini
- (void)analyzePage {
    NSString *apiKey = [self readAPIKey];
    if (!apiKey.length) {
        self.answerView.text = @"Hãy nhập API Key rồi bấm “Lưu API Key”.";
        self.menuVisible = YES;
        self.menuView.hidden = NO;
        return;
    }
    if (self.webView.bounds.size.width < 2 || self.webView.bounds.size.height < 2) return;

    [self.view endEditing:YES];
    self.menuVisible = YES;
    self.menuView.hidden = NO;
    self.answerView.text = @"Đang chụp trang và gửi ảnh đến Gemini…";
    [self.spinner startAnimating];

    // Chỉ chụp nội dung WKWebView do chính ứng dụng này hiển thị.
    // iOS không cho ứng dụng tự ý chụp màn hình của ứng dụng khác.
    dispatch_async(dispatch_get_main_queue(), ^{
        UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:self.webView.bounds.size];
        UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext * _Nonnull context) {
            [self.webView drawViewHierarchyInRect:self.webView.bounds afterScreenUpdates:YES];
        }];
        NSData *jpeg = UIImageJPEGRepresentation(image, 0.65);
        if (!jpeg) {
            [self.spinner stopAnimating];
            self.answerView.text = @"Không tạo được ảnh trang web.";
            return;
        }
        [self sendImageData:jpeg apiKey:apiKey];
    });
}

- (void)sendImageData:(NSData *)imageData apiKey:(NSString *)apiKey {
    NSString *base64 = [imageData base64EncodedStringWithOptions:0];
    NSString *prompt = @"Bạn là trợ lý học tập. Hãy đọc nội dung câu hỏi trong ảnh. Nếu là câu hỏi trắc nghiệm, phân tích từng lựa chọn rồi nêu đáp án có khả năng đúng nhất và giải thích ngắn gọn. Nếu ảnh mờ hoặc thiếu dữ kiện, hãy nói rõ phần không đọc được và không đoán bừa. Trình bày bằng tiếng Việt.";
    NSDictionary *body = @{
        @"contents": @[@{@"parts": @[
            @{@"text": prompt},
            @{@"inline_data": @{@"mime_type": @"image/jpeg", @"data": base64}}
        ]}],
        @"generationConfig": @{@"temperature": @0.2, @"maxOutputTokens": @1200}
    };
    NSError *jsonError = nil;
    NSData *bodyData = [NSJSONSerialization dataWithJSONObject:body options:0 error:&jsonError];
    if (!bodyData) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.spinner stopAnimating];
            self.answerView.text = @"Lỗi tạo dữ liệu gửi Gemini.";
        });
        return;
    }
    NSURL *url = [NSURL URLWithString:@"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST";
    request.HTTPBody = bodyData;
    request.timeoutInterval = 90;
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:apiKey forHTTPHeaderField:@"x-goog-api-key"];

    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSString *resultText = nil;
        if (error) {
            resultText = [NSString stringWithFormat:@"Lỗi kết nối: %@", error.localizedDescription];
        } else {
            NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
            NSDictionary *json = data ? [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil] : nil;
            if (http.statusCode < 200 || http.statusCode >= 300) {
                NSDictionary *err = json[@"error"];
                resultText = [NSString stringWithFormat:@"Gemini API lỗi (%ld): %@", (long)http.statusCode, err[@"message"] ?: @"Không có thông tin lỗi."];
            } else {
                NSArray *parts = json[@"candidates"][0][@"content"][@"parts"];
                NSMutableArray *texts = [NSMutableArray array];
                for (NSDictionary *part in parts) if ([part[@"text"] isKindOfClass:NSString.class]) [texts addObject:part[@"text"]];
                resultText = [texts componentsJoinedByString:@"\n"];
                if (!resultText.length) resultText = @"Gemini không trả về nội dung văn bản.";
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.spinner stopAnimating];
            self.answerView.text = resultText;
        });
    }] resume];
}

@end
